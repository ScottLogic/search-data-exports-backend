//let returnJSON = search.performESSearch(searchJson);
let returnJSON;
//let returnJSON =  search.performESSearch(searchJson);
// const requestJSON = async() => {
//     console.log(`THIS`);
//     returnJSON = await search.performESSearch(searchJson);
//     res.status(200).send(returnJSON);
// };
// requestJSON();

//console.log(`api return`,returnJSON);
    
    
    // returnJSON.then( () => {
    //     console.log(`Finished`);
    //     console.log(returnJSON);
    //     res.status(200).send(returnJSON.body)
    // },() => {
    //     console.log(`Errored`);
    //     res.status(200).send("THIS IS AN ERROR");
    // })

    
    async performESSearch(searchJSON) {
        console.log(`Start ES Search`);
        const actualJSON = { body:searchJSON, index: "posts" };
        console.log(`RequestJSON made`);
        let result = await client.search(actualJSON); // result is a promise. 
        console.log(result);
        console.log(`About to end`);
        return result;
        
    }

    getStuff(request) {
        client.search(request, (err,res) => 
        {
            console.log(`Return `,res.body);
            return res;
        });        
    }

    // doSearch(request) {                
    //     client.search(request).then( (result) => {
    //         console.log(`resulting`,result);
    //         return result;
    //     });                        
    //     //return result;
    // }

    seachPost2 (searchJSON) {
        console.log(`Starting`);
        const actualJSON = {
            body:searchJSON,
            index: "posts"
        }

        const a = this.getStuff(actualJSON);

        //console.log(`Getting`);
        //let a = await this.getStuff(actualJSON);        

        console.log(`POST THING`,a);
        return a;
    }

    searchPost( searchJSON ) {    
        
        const actualJSON = {
            body:searchJSON,
            index: "posts"
        }

        //let searchResults = this.doSearch(actualJSON);  
        console.log(`Pre Search`);
        const x = client.search(actualJSON).then( ( result ) => {
            console.log(`Search Complete`);
        });
        console.log(`Post Search`);
        return x;
        
        // searchResults.then( function(result) {
        //     console.log(`Done`);
        // },function (err) {
        //     console.log(`Broke`);
        // })

        // searchResults.then( x => {
        //     console.log(`THISIS`,x);
        //     return x;
        // })        

        // console.log(`Let!!!`,searchResults);
        // searchResults.then( (result) => {
        //     console.log(`work`,result);
        //     return { "ok":"ok"}
        // }, () => {
        //     console.log(`errored`);
        //     return { "ok": "no"}
        // })
        //return {};
        

        // client.search({            
        //     body:searchJSON,
        //     index: "posts"
        // }, (err,res) => {
        //     console.log(res.body);
        //     console.log(err,`Error`);
        //     return res.body;
        // });   
        console.log(`Returned`) ;
    }

    
    searchPosts(searchJSON) {
        let returnJSON;      
        console.log(`Define the promise thing`);
        const searchResults = async() => {
            console.log("Search function")
            returnJSON = await this.doSearch({body:searchJSON,index: "posts"});
            console.log(`return JSON`,(returnJSON)? true: false);
            return returnJSON;
        }
        console.log(`Run the process`,(returnJSON)? true: false);
        searchResults();
        console.log(`Ran the Process`,(returnJSON)? true: false);
        //return returnJSON;
        // console.log(`HHHHH`,returnJSON);
        // console.log("returning - Main flow");
    }

    
    /* {
  "query": { 
  	"bool": {
  		"must": [
  			{ "multi_match": { "query": "ADAM Lyall",  "fields": [ "LastName","FirstName", "EmailAddress" } },
  			{ "match": { "Tags": "percent" } },
  			{ "term": { "Content": "clear" } }
  			
  		],
      "filter": [ 
      	{ "term": { "_type": "post" } },
        { "range": { "DateCreated": { "gte": "2018-01-01" }}} ,
        { "range": { "DateCreated": { "lte": "2020-01-01" }}} 
      ]
  	}
  }
}
    */
